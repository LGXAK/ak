package com.gui.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gui.bean.User;
import com.gui.dao.IUserDao_mybatis;

@Service("userService")
public class UserService {
	@Autowired
	private IUserDao_mybatis userMapper;
	private Logger log = Logger.getLogger("UserService��class");

	
	// ע���û�
	public int zhuce(User user) {
		log.info("�ο�ע����һ���û�:"+user.getUsername());
		return userMapper.zhuce(user);
		
	}

	// ��¼����
	public User login(User user) {
		return userMapper.login(user);
	}
}
