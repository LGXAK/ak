package com.gui.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.gui.bean.News;

public class NewsMapper implements RowMapper<News> {

	@Override
	public News mapRow(ResultSet arg0, int arg1) throws SQLException {
		
		return new News(arg0.getInt(1), arg0.getString("newsTitle"), 
				arg0.getString("newsContent"), arg0.getString("newsStatus"), 
				arg0.getString("newsPhotoUrl"), arg0.getString("newsType"), 
				arg0.getDate("createTime"));
	}

}
