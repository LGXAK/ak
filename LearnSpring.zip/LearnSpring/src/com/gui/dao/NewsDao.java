package com.gui.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.gui.bean.News;
import com.gui.bean.User;
import com.gui.util.NewsMapper;
import com.gui.util.UserMapper;

@Repository
public class NewsDao {
	@Autowired  //IOC����(����ע�뼼��)  ע��
	private JdbcTemplate jdbcTemplate;
	
	//ע���û�
	public int zhuce(User user){
		String sql = "insert into user(username,password,email,sex,photoUrl) values(?,?,?,?,?);";
		int resultNum = jdbcTemplate.update(sql, new Object[]{user.getUsername(),user.getPassword(),
				user.getEmail(),user.getSex(),user.getPhotoUrl()});
		return resultNum;
	}
	
	//��¼����
	public User login(User user){
		String sql = "select * from user where username=? and password = ?";
		User userdb = null;
		try {
			userdb = jdbcTemplate.queryForObject(sql, 
					new Object[]{user.getUsername(),user.getPassword()}, new UserMapper());
		} catch (DataAccessException e) {
			e.printStackTrace();
			userdb = null;
		}
		return userdb;
	}
	
	//��ҳ��ѯ���ű���Ϣ
	public List<News> selectNews(int pageSize,int pageNumber){
		String sql="select * from news limit ?,?";
		return jdbcTemplate.query(sql,
				new Object[]{(pageNumber-1)*pageSize,pageSize}, 
				new NewsMapper());
	}
	
	//ͳ�����ű���������
	public int selectNewscount(){
		String sql="select count(*) from news";
		return jdbcTemplate.queryForInt(sql);
	}
	
	//ɾ��ĳID���ű���Ϣ
	public int deleteNews(int id){
		String sql = "delete from news where newsId=?";
		return jdbcTemplate.update(sql, new Object[]{id});
	}
	
	//����ĳID��ѯ���ű���Ϣ
	public News selectById(int id){
		String sql = "select * from news where newsId=?";
		return jdbcTemplate.queryForObject(sql, new Object[]{id}, new NewsMapper());
//				query(sql, new Object[]{id}, new NewsMapper()).get(0);
	}
	
	//�޸�ĳID���ű���Ϣ
	public int updateNews(News news){
		String sql  = "update news set newsTitle=? ,newsContent=? ,newsType=? where newsId=?";
		return jdbcTemplate.update(sql,new Object[]{news.getNewsTitle(),
				news.getNewsContent(),news.getNewsType(),news.getNewsId()});
	}
	
	//����������ű���Ϣ
	public int shenheNews(int id){
		String sql  = "update news set newsStatus=? where newsId=?";
		return jdbcTemplate.update(sql,new Object[]{"�����",id});
	}
	
	//�������ű���Ϣ
	public int addNews(News news){
		String sql = "insert into news(newsTitle,newsContent,newsStatus,newsPhotoUrl,newsType,createTime)"
				+ "values(?,?,?,?,?,?)";
		return jdbcTemplate.update(sql,new Object[]{news.getNewsTitle(),news.getNewsContent(),"δ���",
				news.getNewsPhotoUrl(),news.getNewsType(),new Date()});
	}
	
	//��������
	public List<News> select(String selectType,String selectContent){
//		String sql = null;
//		if("newsId".equals(selectType)){
//			sql = "select * from news where newsId=?";
//		}else if("newsTitle".equals(selectType)){
//			selectContent = "%"+selectContent+"%";
//			sql = "select * from news where newsTitle like ?";
//		}else if("newsType".equals(selectType)){
//			sql = "select * from news where newsType=?";
//		}else if("newsContent".equals(selectType)){
//			selectContent = "%"+selectContent+"%";
//			sql = "select * from news where newsContent like ?";
//		}else if("createTime".equals(selectType)){
//			sql = "select * from news where createTime=?";
//		}else if("newsStatus".equals(selectType)){
//			sql = "select * from news where newsStatus=?";
//		}
//		
//		return jdbcTemplate.query(sql,
//				new Object[]{selectContent}, 
//				new NewsMapper());
		String sql = null;
		if("newsTitle".equals(selectType)||"newsContent".equals(selectType)){
			sql = "select * from news where "+selectType+" like '%"+selectContent+"%'";
		}else{
			sql = "select * from news where "+selectType+"="+selectContent;
		}
		return jdbcTemplate.query(sql, new NewsMapper());
	}
	

}
