package com.gui.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.gui.bean.User;

public class Myinterceptor implements HandlerInterceptor {

	@Override
	public void afterCompletion(HttpServletRequest arg0,
			HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		// TODO Auto-generated method stub
		System.out.println("preHandle:����spring������!");

	}

	@Override
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1,
			Object arg2, ModelAndView arg3) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("preHandle:����spring������!");

	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse arg1,
			Object arg2) throws Exception {
		// TODO Auto-generated method stub
		String requestURL=request.getRequestURI();
		if(requestURL.indexOf("showNews.do")>0 || requestURL.indexOf("addNews.do")>0){
		System.out.println("preHandle:����spring������!");
		HttpSession session=request.getSession();
		User user_session=(User)session.getAttribute("user");
		if(user_session!=null){
			return true;
		
		}else{
			request.getRequestDispatcher("login.do").forward(request, arg1);
			return false;
		}
	}else{
		
		return true;
	}
		
		
	}
}
