package com.gui.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.gui.bean.News;
import com.gui.bean.User;
import com.gui.dao.NewsDao_mybatis;
import com.gui.service.NewsService;
import com.gui.service.UserService;

@Controller
public class NewsController {
	
	
	@Autowired
	private UserService userService;
	@Autowired
	private NewsService newsService;
	
	
	@RequestMapping("select.do")
	public String select(String selectType,String selectContent,Model model){
		List<News> newsList = newsService.select(selectType, selectContent);
		model.addAttribute("list", newsList);
		return "newsList";
	}
	
	@RequestMapping("exit.do")
	public String sessionExit(HttpSession session){
		session.removeAttribute("user");
		return "login";
	}

	@RequestMapping("login.do")
	public String login(User user, HttpSession session) {
		System.out.println("NewsController,������");
		String resultPage = "login";
		User user_session = (User) session.getAttribute("user");
		// �ж��Ƿ��¼��
		if (user_session != null) {
			resultPage = "redirect:showNews.do";
		} else {
			User userdb = userService.login(user);
			// �ж��Ƿ��¼�ɹ�
			if (userdb != null) {
				resultPage = "redirect:showNews.do";
				session.setAttribute("user", userdb);
			}
		}
		return resultPage;
	}
	
	@RequestMapping("toZhuce.do")
	public String jumpZhuce(){
		return "zhuce";
	}

	@RequestMapping("zhuce.do")
	public String zhuce(User user, @RequestParam MultipartFile photo2,
			HttpServletRequest request) {
		String resultPage = "zhuce";
		// 1.����ڷ�������λ�ã�����·����
		String realpath = request.getSession().getServletContext()
				.getRealPath("touxiang");
		System.out.println(realpath);
		// 2.������Ŀ���ļ�File(���·�����ļ���+ʱ���)
		String photoName = new Date().getTime() + photo2.getOriginalFilename();
		File targetFile = new File(realpath, photoName);
		// 3.����MultipartFile�е�ת���ļ��ķ�����ת�Ƶ�Ŀ���ļ���
		try {
			photo2.transferTo(targetFile);
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// 4.News�����ļ������·��
		String savePath = request.getContextPath() + "/touxiang/" + photoName;
		user.setPhotoUrl(savePath);
		int resultNum = userService.zhuce(user);
		if (resultNum > 0) {
			resultPage = "login";
		}
		return resultPage;
	}

	// ������spring�������ö��� Model HttpServletRequest HttpServletResponse
	// HttpCookie HttpSession Application
	@RequestMapping("showNews.do")
	public String showNews(String pageNumber, Model model,Map map) {
		int pageNum2 = (pageNumber == null) ? 1 : Integer.valueOf(pageNumber);
		int pageSize = 10;

		// ͳ�����ű���������
		int count = newsService.selectNewscount();
		// �������������βҳ��
		int weiye = count % pageSize == 0 ? count / pageSize : count / pageSize
				+ 1;
		// ҳ��ķ�Χ��(1,weiye)
		pageNum2 = (pageNum2 < 1) ? 1 : pageNum2;
		pageNum2 = (pageNum2 > weiye) ? weiye : pageNum2;

//		Page page = new Page(pageSize, pageNum2);
		int beginSize = (pageNum2-1)*pageSize;
		map.put("pSize", pageSize);
		map.put("bSize", beginSize);
		List<News> newsList = newsService.selectNews(map);

		// ͨ��model��list��������newsList.jsp
		model.addAttribute("list", newsList);
		// ͨ��model��ҳ�����pageNum����newsList.jsp
		model.addAttribute("pageNum", pageNum2);
		// ͨ��model��pageCount����newsList.jsp
		model.addAttribute("pageCount", weiye);
		return "newsList";
	}

	@RequestMapping("deleteNews.do")
	// String newsId ��Ϊ int Spring����������װ����
	public String deleteNews(int newsId) {
		String resultPage = "error";
		int resultNum = newsService.deleteNews(newsId);
		if (resultNum > 0) {
			resultPage = "redirect:showNews.do";
		}
		return resultPage;
	}

	@RequestMapping("toUpdatePage.do")
	public String toUpdatePage(int newsId, Model model) {
		String resultPage = "error";
		News newsdb = newsService.selectById(newsId);
		if (newsdb != null) {
			resultPage = "updateNews";
			// ͨ��model��news����updateNews.jsp
			model.addAttribute("news", newsdb);
			System.out.println(newsdb);
		}

		return resultPage;
	}

	@RequestMapping("updateNews.do")
	public String updateNews(News news) {
		String resultPage = "error";
		System.out.println(news);
		int resultNum = newsService.updateNews(news);
		if (resultNum > 0) {
			resultPage = "redirect:showNews.do";
		}
		return resultPage;
	}

	@RequestMapping("shenhe.do")
	public String shenheNews(int[] shenheId) {
		String resultPage = "error";
		int resultNum = 0;
		for (int id : shenheId) {
			News news = new News();
			news.setNewsId(id);
			news.setNewsStatus("�����");
			resultNum = newsService.shenheNews(news);
		}

		if (resultNum > 0) {
			resultPage = "redirect:showNews.do";
		}
		return resultPage;
	}

	@RequestMapping("toAddNews.do")
	public String toAddNews() {
		return "addNews";
	}

	@RequestMapping("addNews.do")
	public String addNews(News news, @RequestParam MultipartFile photo,
			HttpServletRequest request) {
		String resultPage = "error";
		// 1.����ڷ�������λ�ã�����·����
		String realpath = request.getSession().getServletContext()
				.getRealPath("file");
		System.out.println(realpath);
		// 2.������Ŀ���ļ�File(���·�����ļ���+ʱ���)
		String photoName = new Date().getTime() + photo.getOriginalFilename();
		File targetFile = new File(realpath, photoName);
		// 3.����MultipartFile�е�ת���ļ��ķ�����ת�Ƶ�Ŀ���ļ���
		try {
			photo.transferTo(targetFile);
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// 4.News�����ļ������·��
		String savePath = request.getContextPath() + "/file/" + photoName;
		news.setNewsPhotoUrl(savePath);
		news.setNewsStatus("δ���");
		news.setCreateTime(new Date());
		int resultNum = newsService.addNews(news);
		if (resultNum > 0) {
			resultPage = "redirect:showNews.do";
		}
		return resultPage;
	}
}
