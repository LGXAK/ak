package com.gui.bean;

public class Para {
	private String selectType;
	private String selectContent;
	
	
	
	public Para(String selectType, String selectContent) {
		super();
		this.selectType = selectType;
		this.selectContent = selectContent;
	}
	public Para() {
		super();
	}
	public String getSelectType() {
		return selectType;
	}
	public void setSelectType(String selectType) {
		this.selectType = selectType;
	}
	public String getSelectContent() {
		return selectContent;
	}
	public void setSelectContent(String selectContent) {
		this.selectContent = selectContent;
	}
	@Override
	public String toString() {
		return "Para [selectType=" + selectType + ", selectContent="
				+ selectContent + "]";
	}
	
	
}
