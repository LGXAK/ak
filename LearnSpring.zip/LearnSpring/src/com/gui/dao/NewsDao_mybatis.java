package com.gui.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.gui.bean.News;
import com.gui.bean.Para;
import com.gui.bean.User;

@Repository
public class NewsDao_mybatis extends SqlSessionDaoSupport{
	@Autowired
	// IOC����(����ע�뼼��) ע��
	private JdbcTemplate jdbcTemplate;

	//��һ�ֻ�ȡsqlSession  ��Ҫextends SqlSessionDaoSupport
	@Autowired
	private SqlSessionFactoryBean sqlSessionFactory;
	
	//�ڶ��ֻ�ȡsqlSession  ����Ҫextends SqlSessionDaoSupport  ��Ҫ��spring.xml�ļ�������sqlSession��bean����
	@Autowired
	private SqlSession sqlSession;


	// ��ҳ��ѯ���ű���Ϣ
	public List<News> selectNews(Map map) {

		return sqlSession.selectList("mapper.NewsMapper.selectByPage", map);
	}

	// ͳ�����ű���������
	public int selectNewscount() {
		return (Integer) sqlSession.selectOne("mapper.NewsMapper.selectCount");
	}

	// ɾ��ĳID���ű���Ϣ
	public int deleteNews(int id) {
		return sqlSession.delete("mapper.NewsMapper.deleteNews", id);
	}

	// ����ĳID��ѯ���ű���Ϣ
	public News selectById(int id) {
		return (News) sqlSession.selectOne("mapper.NewsMapper.selectNewsById",
				id);
	}

	// �޸�ĳID���ű���Ϣ
	public int updateNews(News news) {
		return sqlSession.update("mapper.NewsMapper.updateNews", news);
	}

	// ����������ű���Ϣ
	public int shenheNews(News news) {
		return sqlSession.update("mapper.NewsMapper.shenheNews", news);
	}

	// �������ű���Ϣ
	public int addNews(News news) {
		return sqlSession.insert("mapper.NewsMapper.addNews", news);
	}

	// ��������
	public List<News> select(String selectType, String selectContent) {
		// String sql = null;
		// if("newsId".equals(selectType)){
		// sql = "select * from news where newsId=?";
		// }else if("newsTitle".equals(selectType)){
		// selectContent = "%"+selectContent+"%";
		// sql = "select * from news where newsTitle like ?";
		// }else if("newsType".equals(selectType)){
		// sql = "select * from news where newsType=?";
		// }else if("newsContent".equals(selectType)){
		// selectContent = "%"+selectContent+"%";
		// sql = "select * from news where newsContent like ?";
		// }else if("createTime".equals(selectType)){
		// sql = "select * from news where createTime=?";
		// }else if("newsStatus".equals(selectType)){
		// sql = "select * from news where newsStatus=?";
		// }
		//
		// return jdbcTemplate.query(sql,
		// new Object[]{selectContent},
		// new NewsMapper());
		Para para = new Para(selectType, selectContent);
		System.out.println(para);
		return sqlSession.selectList("mapper.NewsMapper.selectByVaule", para);

	}

}
