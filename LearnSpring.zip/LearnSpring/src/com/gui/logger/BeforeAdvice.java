package com.gui.logger;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

import com.sun.istack.internal.logging.Logger;

public class BeforeAdvice implements MethodBeforeAdvice {
	private static Logger logger=Logger.getLogger(BeforeAdvice.class);

	@Override
	public void before(Method method, Object[] target, Object arg2) throws Throwable {
		// TODO Auto-generated method stub
     logger.info("ǰ��֪ͨ�ࣺ"+target.getClass().getName()+"��"+method.getName()+"������ִ��");


	}

}
