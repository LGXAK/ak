package com.gui.bean;

import java.util.Date;

public class News {
 private int newsId;
 private String newsTitle;
 private String newsContent;
 private String newsStatus;
 private String newsPhotoUrl;
 private String newsType;
 private Date createTime;
public News() {
	super();
}
public News(int newsId, String newsTitle, String newsContent,
		String newsStatus, String newsPhotoUrl, String newsType, Date createTime) {
	super();
	this.newsId = newsId;
	this.newsTitle = newsTitle;
	this.newsContent = newsContent;
	this.newsStatus = newsStatus;
	this.newsPhotoUrl = newsPhotoUrl;
	this.newsType = newsType;
	this.createTime = createTime;
}



public int getNewsId() {
	return newsId;
}
public void setNewsId(int newsId) {
	this.newsId = newsId;
}
public String getNewsTitle() {
	return newsTitle;
}
public void setNewsTitle(String newsTitle) {
	this.newsTitle = newsTitle;
}
public String getNewsContent() {
	return newsContent;
}
public void setNewsContent(String newsContent) {
	this.newsContent = newsContent;
}
public String getNewsStatus() {
	return newsStatus;
}
public void setNewsStatus(String newsStatus) {
	this.newsStatus = newsStatus;
}
public String getNewsPhotoUrl() {
	return newsPhotoUrl;
}
public void setNewsPhotoUrl(String newsPhotoUrl) {
	this.newsPhotoUrl = newsPhotoUrl;
}
public String getNewsType() {
	return newsType;
}
public void setNewsType(String newsType) {
	this.newsType = newsType;
}
public Date getCreateTime() {
	return createTime;
}
public void setCreateTime(Date createTime) {
	this.createTime = createTime;
}
@Override
public String toString() {
	return "News [newsId=" + newsId + ", newsTitle=" + newsTitle
			+ ", newsContent=" + newsContent + ", newsStatus=" + newsStatus
			+ ", newsPhotoUrl=" + newsPhotoUrl + ", newsType=" + newsType
			+ ", createTime=" + createTime + "]";
}


 
}
